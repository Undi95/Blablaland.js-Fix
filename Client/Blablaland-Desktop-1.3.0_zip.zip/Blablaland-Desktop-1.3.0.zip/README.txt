Pour lancer le client, il faut d'abord le dezipper dans le dossier Client à côté du fichier .bat (il était trop lourd), ensuite soit :
- Vous lancez le .bat prévu à cet effet après avoir lancer votre serveur
- Vous créez un raccourci du client, et vous modifier le chemin comme ceci : ...\Blablaland-Desktop-1.3.0.exe --target=http://localhost:80/

Dans le premier cas, il n'y a rien à faire.

Dans le deuxieme, il faut rajouter --target=http://localhost:80/ à la fin du chemin du raccourci, pour que le client puisse se connecter à votre serveur.

Pseudo : Admin
Mot de passe : Admin